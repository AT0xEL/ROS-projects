#! /usr/bin/env python

import rospy

rospy.init_node('ObiWan')
print("Help me Obi-Wan Kenobi, you're my only hope")